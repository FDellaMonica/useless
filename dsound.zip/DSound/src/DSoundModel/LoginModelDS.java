package DSoundModel;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;


public class LoginModelDS implements LoginModel{
	private static DataSource ds;
	private CartaDiCreditoDS cartads = new CartaDiCreditoDS();
	
	static {
		try {
			Context initCtx = new InitialContext();
			Context envCtx = (Context) initCtx.lookup("java:comp/env");
			
			ds = (DataSource) envCtx.lookup("jdbc/is");
			
		} catch (NamingException e) {
			System.out.println("Error:" + e.getMessage());
		}
	}
	public static String TABLE_NAME ="utente";
	
	public synchronized UserBean doCheckLogin(String email,String password) throws SQLException{

		Connection connection=null;
		PreparedStatement preparedStatement = null;
		String selectSQL = "SELECT * FROM " + LoginModelDS.TABLE_NAME + " WHERE email= ? && password=?";
	
	try{
		connection=ds.getConnection();
		preparedStatement=connection.prepareStatement(selectSQL);
		preparedStatement.setString(1,email);
		preparedStatement.setString(2,password);
		
		ResultSet rs = preparedStatement.executeQuery();

		if(rs.next()) {
			UserBean bean = new UserBean();
			
			bean.setNickname(rs.getString("nickname"));
			bean.setEmail(rs.getString("email"));
			bean.setPassword(rs.getString("password"));
			bean.setRuolo(rs.getString(("Admin")));
			bean.setNome(rs.getString("nome"));
			bean.setCognome(rs.getString("cognome"));
			
			return bean;
		}
		return null;
	}catch(Exception e) {System.out.println(e);}
	finally {
		try {
			if (preparedStatement != null)
				preparedStatement.close();
		} finally {
			if (connection != null)
				connection.close();
		}
	}return null;
	}

	public synchronized void doSaveUser(UserBean user, CartaDiCredito userCard) throws SQLException {
		
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		String insertSQL = "INSERT INTO utente (nickname, email, cognome, password, nome, Admin)  VALUES (?,?,?,?,?,?)";

		try {
			connection = ds.getConnection();
			
			preparedStatement = connection.prepareStatement(insertSQL);
			preparedStatement.setString(1, user.getNickname());
			preparedStatement.setString(2, user.getEmail());
			preparedStatement.setString(3, user.getCognome());
			preparedStatement.setString(4, user.getPassword());
			preparedStatement.setString(5, user.getNome());
			preparedStatement.setString(6, user.getRuolo());
			
			preparedStatement.executeUpdate();

			connection.commit();
			
			if(userCard != null) 
			{
				System.out.println("Adesso inserisco la carta di credito!");
				cartads.doSaveUser(userCard,user.getEmail());
			}
			
		}
		catch(Exception eq) {System.out.println(eq);}
		finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
	}
	
	public synchronized boolean doUpdate(UserBean user) throws SQLException 
	{
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		int result = 0;

		String deleteSQL = "UPDATE utente SET nickname = ?, email = ?, cognome = ?, password = ?, nome = ?, Admin = ? WHERE email = ?";

		try {
			connection = ds.getConnection();
			preparedStatement = connection.prepareStatement(deleteSQL);
			System.out.println(user.getNome());
			preparedStatement.setString(1, user.getNickname());
			preparedStatement.setString(2, user.getEmail());
			preparedStatement.setString(3, user.getCognome());
			preparedStatement.setString(4, user.getPassword());
			preparedStatement.setString(5, user.getNome());
			preparedStatement.setString(6, user.getRuolo());
			preparedStatement.setString(7, user.getEmail());
			result = preparedStatement.executeUpdate();
			connection.commit();
		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
		
		return (result != 0);
	}
	
	public synchronized boolean doDelete(String mail) throws SQLException 
	{
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		int result = 0;

		String deleteSQL = "DELETE FROM utente WHERE email = ?";

		try {
			connection = ds.getConnection();
			preparedStatement = connection.prepareStatement(deleteSQL);
			preparedStatement.setString(1, mail);

			result = preparedStatement.executeUpdate();

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
		System.out.println("result "+result);
		
		return (result != 0);
	}
}
