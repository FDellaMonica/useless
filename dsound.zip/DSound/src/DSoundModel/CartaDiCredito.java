package DSoundModel;

import java.io.Serializable;
import java.sql.Date;

public class CartaDiCredito implements Serializable {

	String numeroCarta;
	int CVV;
	Date dataDiScadenza;
	String proprietario;
	
	
	public CartaDiCredito() {
		super();
	}
	public CartaDiCredito(String numeroCarta, int cVV, Date dataDiScadenza, String proprietario) {
		super();
		this.numeroCarta = numeroCarta;
		CVV = cVV;
		this.dataDiScadenza = dataDiScadenza;
		this.proprietario = proprietario;
	}
	public String getNumeroCarta() {
		return numeroCarta;
	}
	public void setNumeroCarta(String numeroCarta) {
		this.numeroCarta = numeroCarta;
	}
	public int getCVV() {
		return CVV;
	}
	public void setCVV(int cVV) {
		CVV = cVV;
	}
	public Date getDataDiScadenza() {
		return dataDiScadenza;
	}
	public void setDataDiScadenza(Date dataDiScadenza) {
		this.dataDiScadenza = dataDiScadenza;
	}
	public String getProprietario() {
		return proprietario;
	}
	public void setProprietario(String proprietario) {
		this.proprietario = proprietario;
	}
}
