package DSoundModel;

import java.io.Serializable;

public class UserBean implements Serializable{
	private static final long serialVersionUID = 1L;
	
	String nickname;
	String email;
	String password;
	String cognome;
	String nome;
	String ruolo;
	CartaDiCredito cartaDiCredito;
	
	public UserBean() {
		super();
	}
	public UserBean(String nickname, String email, String password, String cognome, String nome, String ruolo,
			CartaDiCredito cartaDiCredito) {
		super();
		this.nickname = nickname;
		this.email = email;
		this.password = password;
		this.cognome = cognome;
		this.nome = nome;
		this.ruolo = ruolo;
		this.cartaDiCredito = cartaDiCredito;
	}
	public String getNickname() {
		return nickname;
	}
	public void setNickname(String nickname) {
		this.nickname = nickname;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getCognome() {
		return cognome;
	}
	public void setCognome(String cognome) {
		this.cognome = cognome;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getRuolo() {
		return ruolo;
	}
	public void setRuolo(String ruolo) {
		this.ruolo = ruolo;
	}
	public CartaDiCredito getCartaDiCredito() {
		return cartaDiCredito;
	}
	public void setCartaDiCredito(CartaDiCredito cartaDiCredito) {
		this.cartaDiCredito = cartaDiCredito;
	}
	
	

}
