package DSoundModel;

import java.sql.SQLException;
import java.util.Collection;


public interface ProdottoModel {
	
	public void doSave(ProdottoBean product) throws SQLException;
	public boolean doDelete(int code) throws SQLException;
	public ProdottoBean doRetrieveByKey(int code) throws SQLException;
	public Collection<ProdottoBean> doRetrieveAll(String order) throws SQLException;
	public void setTableName(String table );
	public String getTableName();
	public boolean doUpdate(ProdottoBean product) throws SQLException;
	public boolean setValutazioneByID(int ID,String valutazione) throws SQLException;
}
