package DSoundModel;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;

public interface BeneModel 
{
	public void doSave(BeneBean product,int prodotto) throws SQLException;

	public boolean doDelete(int code) throws SQLException;

	public BeneBean doRetrieveByKey(int code) throws SQLException;
	
	public ArrayList<BeneBean> doRetrieveByUtente(String mail,String nickname) throws SQLException;
	
	public  boolean doControl(int idprodotto, String nickname)throws SQLException;
	
	public ArrayList<BeneBean> doRetrieveAll(String order) throws SQLException;
}