package DSoundModel;

import java.sql.SQLException;

import DSoundModel.CartaDiCredito;

public interface CartaDiCreditoI {
	public CartaDiCredito doRetrieve(String email,String nickname) throws SQLException;
	public void doSaveUser(CartaDiCredito user, String email) throws SQLException;
	public boolean doUpdate(CartaDiCredito user,String email) throws SQLException; 
	public boolean doDelete(String mail) throws SQLException;

}