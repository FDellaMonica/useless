package DSoundModel;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;


public class CartaDiCreditoDS implements CartaDiCreditoI {

private static DataSource ds;
	
	
	static {
		try {
			Context initCtx = new InitialContext();
			Context envCtx = (Context) initCtx.lookup("java:comp/env");
			
			ds = (DataSource) envCtx.lookup("jdbc/is");
		}catch (NamingException e) {
			System.out.println("Error:" + e.getMessage());
		}
	}
	public static String TABLE_NAME = "carta_di_credito";

	public synchronized CartaDiCredito doRetrieve(String email, String nickname) throws SQLException {
		Connection connection=null;
		PreparedStatement preparedStatement=null;
		String selectSQL= "SELECT * FROM " + CartaDiCreditoDS.TABLE_NAME + " WHERE email = (Select email From is.utente WHERE email = ?)";
		try {
			connection=ds.getConnection();
			
			preparedStatement=connection.prepareStatement(selectSQL);
			preparedStatement.setString(1,email);

			ResultSet rs= preparedStatement.executeQuery();
			if(rs.next()) {
				CartaDiCredito carta =new CartaDiCredito();
				carta.setNumeroCarta(rs.getString("NumeroCarta"));
				carta.setCVV(rs.getInt("CVV"));
				carta.setDataDiScadenza(rs.getDate("DataScadenza"));
				carta.setProprietario(rs.getString("Proprietario"));

				return carta;
				
			}
		return null;
	}finally{
		try {
			if(preparedStatement != null)
				preparedStatement.close();
		
		}finally {
			if(connection !=null)
				connection.close();
		}
	}
		}

	@Override
	public synchronized void doSaveUser(CartaDiCredito user, String email) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		String insertSQL = "INSERT INTO " + CartaDiCreditoDS.TABLE_NAME + "(NumeroCarta,CVV,DataScadenza,Proprietario,Email)  VALUES (?,?,?,?,?)";

		try {
			connection = ds.getConnection();
			preparedStatement = connection.prepareStatement(insertSQL);

			preparedStatement.setString(1, user.getNumeroCarta());
			preparedStatement.setInt(2, user.getCVV());

			preparedStatement.setDate(3, user.getDataDiScadenza());
			preparedStatement.setString(4, user.getProprietario());
			preparedStatement.setString(5, email);
			preparedStatement.executeUpdate();

			connection.commit();

		}
		catch(Exception eq) {System.out.println(eq);}
		finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
		
	}

	@Override
	public synchronized boolean doUpdate(CartaDiCredito user,String email) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		int result = 0;

		String deleteSQL = "UPDATE " + CartaDiCreditoDS.TABLE_NAME + " SET NumeroCarta = ?, CVV = ?, DataScadenza = ?, Proprietario = ? WHERE email = ?";
				
		try {
			connection = ds.getConnection();
			preparedStatement = connection.prepareStatement(deleteSQL);

			preparedStatement.setString(1, user.getNumeroCarta());
			preparedStatement.setInt(2, user.getCVV());
			
			preparedStatement.setDate(3, user.getDataDiScadenza());
			preparedStatement.setString(4, user.getProprietario());
			preparedStatement.setString(5, email);
			result = preparedStatement.executeUpdate();
			connection.commit();
		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
		
		System.out.println("result: "+result);
		return (result != 0);		
	}

	@Override
	public synchronized boolean doDelete(String mail) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		int result = 0;

		String deleteSQL = "DELETE FROM " + CartaDiCreditoDS.TABLE_NAME + " indirizzo WHERE email = ?";

		try {
			connection = ds.getConnection();
			preparedStatement = connection.prepareStatement(deleteSQL);
			preparedStatement.setString(1, mail);

			result = preparedStatement.executeUpdate();

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
		return (result != 0);
	}
}
