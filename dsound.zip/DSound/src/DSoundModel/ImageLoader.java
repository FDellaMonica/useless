package DSoundModel;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Scanner;

public class ImageLoader {

	public static void main(String[] args) {
		ProdottoModelDS p= new ProdottoModelDS();
		try 
        {
            Collection<ProdottoBean> lp=new ArrayList<ProdottoBean>();
            lp=p.doRetrieveAll("");

            Object[] a=lp.toArray();
            ArrayList<ProdottoBean> b=new ArrayList<ProdottoBean>();

            for(int i=0;i<a.length;i++)
                b.add((ProdottoBean)a[i]);

            ArrayList<songCover> listaCanzoni= songReader(".\\WebContent\\immagini.txt");

            for(int i=0;i<b.size();i++)
            {
                
                p.doUpdateImage(listaCanzoni.get(i).getIsbn(), listaCanzoni.get(i).getImg());
            }

    }catch(Exception e){}
		
	}
	
        public static ArrayList<songCover> songReader(String path) 
        {
            ArrayList<songCover> IDs=new ArrayList<songCover>();

            try 
            {
              File myObj = new File(path);
              Scanner myReader = new Scanner(myObj);

              while (myReader.hasNextLine()) 
              {
                String data = myReader.nextLine();

                int ID=Integer.valueOf(data.substring(0,data.indexOf("|")));
                String copertina=data.substring(data.indexOf("|")+1,data.length());

                IDs.add(new songCover(ID,".\\WebContent\\images"+copertina));
              }

              myReader.close();
            } catch (FileNotFoundException e) {System.out.println("File non trovato");}

            return IDs;
          }
   
	}
    

