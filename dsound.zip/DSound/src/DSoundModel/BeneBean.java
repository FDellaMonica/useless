package DSoundModel;

import java.sql.Blob;
import java.sql.Date;

public class BeneBean {
	int ID_prodotto;
	String Nickname;
	String Email;
	Date acquisto;
	String nomeProdotto;
	float prezzoProdotto;
	String nomeUtente;
	String cognomeUtente;
	byte[] immagine;
	String autore;
	String genere;
	int valutazione;
	
	public int getID_prodotto() {
		return ID_prodotto;
	}
	public void setID_prodotto(int iD_prodotto) {
		ID_prodotto = iD_prodotto;
	}
	public String getNickname() {
		return Nickname;
	}
	public void setNickname(String nickname) {
		Nickname = nickname;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}
	public Date getAcquisto() {
		return acquisto;
	}
	public void setAcquisto(Date acquisto) {
		this.acquisto = acquisto;
	}
	public String getNomeProdotto() {
		return nomeProdotto;
	}
	public void setNomeProdotto(String nomeProdotto) {
		this.nomeProdotto = nomeProdotto;
	}
	public float getPrezzoProdotto() {
		return prezzoProdotto;
	}
	public void setPrezzoProdotto(float prezzoProdotto) {
		this.prezzoProdotto = prezzoProdotto;
	}
	public String getNomeUtente() {
		return nomeUtente;
	}
	public void setNomeUtente(String nomeUtente) {
		this.nomeUtente = nomeUtente;
	}
	public String getCognomeUtente() {
		return cognomeUtente;
	}
	public void setCognomeUtente(String cognomeUtente) {
		this.cognomeUtente = cognomeUtente;
	}
	public byte[] getImmagine() {
		return immagine;
	}
	public void setImmagine(byte[] immagine) {
		this.immagine = immagine;
	}
	public String getAutore() {
		return autore;
	}
	public void setAutore(String autore) {
		this.autore = autore;
	}
	public String getGenere() {
		return genere;
	}
	public void setGenere(String genere) {
		this.genere = genere;
	}
	public int getValutazione() {
		return valutazione;
	}
	public void setValutazione(int valutazione) {
		this.valutazione = valutazione;
	}
	public BeneBean(int ID_prodotto, String nickname, String email, Date acquisto, String nomeProdotto,
			float prezzoProdotto, String nomeUtente, String cognomeUtente, byte[] immagine, String autore,
			String genere, int valutazione) {
		super();
		this.ID_prodotto = ID_prodotto;
		Nickname = nickname;
		Email = email;
		this.acquisto = acquisto;
		this.nomeProdotto = nomeProdotto;
		this.prezzoProdotto = prezzoProdotto;
		this.nomeUtente = nomeUtente;
		this.cognomeUtente = cognomeUtente;
		this.immagine = immagine;
		this.autore = autore;
		this.genere = genere;
		this.valutazione = valutazione;
	}
	public BeneBean() {
		super();
	}
	
	
	
	
	
}

