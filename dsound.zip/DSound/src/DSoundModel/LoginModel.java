package DSoundModel;

import java.sql.*;
public interface LoginModel 
{
	public UserBean doCheckLogin(String email,String password) throws SQLException;	
	public void doSaveUser(UserBean user, CartaDiCredito userCard) throws SQLException;
	public boolean doUpdate(UserBean user) throws SQLException;
	public boolean doDelete(String mail) throws SQLException;

}
