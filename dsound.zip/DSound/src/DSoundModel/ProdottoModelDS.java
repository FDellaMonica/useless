package DSoundModel;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;
import java.util.LinkedList;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;



public class ProdottoModelDS implements ProdottoModel{

	private static DataSource ds;

	static {
		try {
			Context initCtx = new InitialContext();
			Context envCtx = (Context) initCtx.lookup("java:comp/env");

			ds = (DataSource) envCtx.lookup("jdbc/is");

		} catch (NamingException e) {
			System.out.println("Error:" + e.getMessage());
		}
	}

	public static String TABLE_NAME = "prodotto";

	public String getTableName() {
		return TABLE_NAME;
	}
	public void setTableName(String table) {
		TABLE_NAME=table;
	}
	
	public synchronized void doSave(ProdottoBean product) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		String insertSQL = "INSERT INTO " + ProdottoModelDS.TABLE_NAME	+ " VALUES (?, ?, ?, ?, ?, ?, ?)";

		try {
			connection = ds.getConnection();
			preparedStatement = connection.prepareStatement(insertSQL);
			preparedStatement.setInt(1, product.getID());
			preparedStatement.setString(2, product.getNome());
			preparedStatement.setString(3, product.getGenere());
			preparedStatement.setString(4, product.getAutore());
			
		
			
			InputStream dc=new ByteArrayInputStream(product.getImage());
			preparedStatement.setBinaryStream(5,dc);
			preparedStatement.setInt(6, product.getAnno());
			preparedStatement.setString(7, product.getDurata());
			

			preparedStatement.executeUpdate();
			creaValutazione(product.getID(),product.getValutazione());
			connection.commit();
		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
		
	}
	private static synchronized void creaValutazione(int ID,int value) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		String insertSQL = "INSERT INTO valutazione_prodotto VALUES(?,?)";
		try {
			connection = ds.getConnection();
			preparedStatement = connection.prepareStatement(insertSQL);
			preparedStatement.setInt(1, ID);
			preparedStatement.setInt(2, value);
			preparedStatement.executeUpdate();
			connection.commit();
		}finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
	}
	@Override
	public synchronized boolean doDelete(int code) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		int result = 0;

		String deleteSQL = "DELETE FROM " + ProdottoModelDS.TABLE_NAME + " WHERE CODE = ?";

		try {
			connection = ds.getConnection();
			preparedStatement = connection.prepareStatement(deleteSQL);
			preparedStatement.setInt(1, code);

			result = preparedStatement.executeUpdate();

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
		return (result != 0);
		
	}

	@Override
	public synchronized ProdottoBean doRetrieveByKey(int code) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		ProdottoBean bean = new ProdottoBean();
		
		String selectSQL = "SELECT * FROM " + ProdottoModelDS.TABLE_NAME + " WHERE ID = ?";

		try {
			
			connection = ds.getConnection();
			
			preparedStatement = connection.prepareStatement(selectSQL);

			preparedStatement.setInt(1, code);
						
			ResultSet rs = preparedStatement.executeQuery();
			while (rs.next()) {	
				bean.setID(rs.getInt("ID"));
				bean.setNome(rs.getString("NomeProdotto"));
				
				bean.setGenere(rs.getString("Genere"));
				bean.setAutore(rs.getString("Autore"));
				System.out.println("messaggio1");
				bean.setValutazione(Integer.valueOf(getValutazioneByID(code)));
				Blob imgBlob=(Blob) rs.getBlob("ImmagineProdotto");
				System.out.println("messaggio2");
				bean.setImage(imgBlob.getBytes(1,(int) imgBlob.length()));
				bean.setAnno(rs.getInt("AnnoUscita"));
				bean.setDurata(rs.getString("Durata"));
				
			}

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
		
		return bean;
	}

	@Override
	public synchronized Collection<ProdottoBean> doRetrieveAll(String order) throws SQLException {

		Connection connection = null;
		System.out.println("1");
		
		PreparedStatement preparedStatement = null;
		

		Collection<ProdottoBean> products = new LinkedList<ProdottoBean>();
		
		String selectSQL = "SELECT * FROM " + ProdottoModelDS.TABLE_NAME;
		System.out.println("3");
		
		if (order != null && !order.equals("")) {
			selectSQL += " ORDER BY " + order;
		}

		try {
			connection = ds.getConnection();
		
			preparedStatement = connection.prepareStatement(selectSQL);
			
			ResultSet rs = preparedStatement.executeQuery();
			System.out.println("4");
			

			while (rs.next()) {
				ProdottoBean bean = new ProdottoBean();
				
				bean.setID(rs.getInt("ID"));
				bean.setNome(rs.getString("NomeProdotto"));
				bean.setGenere(rs.getString("genere"));
				bean.setAutore(rs.getString("autore"));	
				bean.setValutazione(Integer.valueOf(this.getValutazioneByID(bean.getID())));
				java.sql.Blob imgBlob= rs.getBlob("ImmagineProdotto");

				
				bean.setImage(imgBlob.getBytes(1,(int) imgBlob.length()));
				bean.setAnno(rs.getInt("AnnoUscita"));
				bean.setDurata(rs.getString("Durata"));
				System.out.println("5");
				
				products.add(bean);
			}
			

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
	}
		return products;
	}

	public synchronized String getValutazioneByID(int ID) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		String selectSQL = "SELECT valutazione_prodotto FROM valutazione_prodotto" + " WHERE ID = ? ";
		try {
			connection = ds.getConnection();
			
			preparedStatement=connection.prepareStatement(selectSQL);
			preparedStatement.setInt(1,ID);
			String risultato = "";
			int somma = 0;
			int i=0;
			ResultSet rs = preparedStatement.executeQuery();
			while(rs.next()) {
				somma += Integer.valueOf(rs.getString("valutazione_prodotto"));
				i++;
			}
			if(i>0) {
				double result = Math.round(somma/i);
				int resInt = (int)result;
				risultato = Integer.toString(resInt);
				return risultato;
			}
		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
		return "";
		
	}
	public synchronized boolean setValutazioneByID(int ID,String valutazione) throws SQLException{
		Connection connection=null;
		PreparedStatement preparedStatement = null;
		String insertSQL="INSERT INTO valutazione_prodotto (ID,valutazione_prodotto) values(?,?)";
		try {
			connection = ds.getConnection();
			
			preparedStatement=connection.prepareStatement(insertSQL);
			preparedStatement.setInt(1, ID);
			preparedStatement.setString(2,valutazione);
			preparedStatement.executeUpdate();
			connection.commit();
			return true;
			
		}
		finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
	}
	}

	@Override
	public boolean doUpdate(ProdottoBean product) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
	
		int result = 0;
		
		String updateSQL = "UPDATE prodotto SET NomeProdotto = ?, genere = ?, autore = ?, ImmagineProdotto = ?, AnnoUscita = ?, Durata = ? WHERE ID = ?" ;
		try {
			connection = ds.getConnection();
			preparedStatement = connection.prepareStatement(updateSQL);
			
			preparedStatement.setString(1, product.getNome());
			preparedStatement.setString(2, product.getGenere());
			preparedStatement.setString(3, product.getAutore());
			
			InputStream dc=new ByteArrayInputStream(product.getImage());
			preparedStatement.setBinaryStream(4,dc);
			preparedStatement.setInt(5,product.getAnno());
			preparedStatement.setString(6, product.getDurata());
			preparedStatement.setInt(7, product.getID());
			
			result = preparedStatement.executeUpdate();
		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
		
		return (result != 0);
	}
	public boolean doUpdateImage(int ID, String photo) throws SQLException{
		Connection connection = null;
		PreparedStatement preparedStatement = null;
	
		int result = 0;
		String updateSQL = "UPDATE prodotto SET ImmagineProdotto = ? WHERE ID = ?" ;
		File file = new File(photo);
        try
            {
                FileInputStream fis = new FileInputStream(file);
                preparedStatement.setBinaryStream(1, fis, fis.available());
                preparedStatement.setInt(2, ID);

                preparedStatement.executeUpdate();
                connection.commit();
            } catch (FileNotFoundException e)
                {
                    System.out.println(e);
                } catch (IOException e) 
                        {
                            System.out.println(e);
                        }
	finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
		
		return (result != 0);
	}
		
}
