package DSoundModel;

public class songCover
{
    private int ID;
    private String img;

    public int getIsbn() {return ID;}
    public void setIsbn(String isbn) {this.ID = ID;}
    public String getImg() {return img;}
    public void setImg(String img) {this.img = img;}

    public songCover(int ID, String img) {
        this.ID = ID;
        this.img = img;
    }
    public songCover() {
    }


}