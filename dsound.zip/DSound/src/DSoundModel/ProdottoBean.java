package DSoundModel;

import java.io.Serializable;
import java.sql.Blob;
import java.util.Arrays;

public class ProdottoBean implements Serializable{
	private static final long serialVersionUID = 1L;

	int ID;
	String nome;
	String genere;
	String autore;
	int valutazione;
	byte[] image;
	int anno;
	String durata;
	public ProdottoBean(int iD, String nome, String genere, String autore, int valutazione, byte[] image,int anno,String durata) {
		super();
		ID = iD;
		this.nome = nome;
		this.genere = genere;
		this.autore = autore;
		this.valutazione = valutazione;
		this.image = image;
		this.anno=anno;
		this.durata=durata;
	}
	public ProdottoBean() {
		super();
	}
	
	public int getAnno() {
		return anno;
	}
	public void setAnno(int anno) {
		this.anno = anno;
	}
	public String getDurata() {
		return durata;
	}
	public void setDurata(String durata) {
		this.durata = durata;
	}
	public int getID() {
		return ID;
	}
	public void setID(int iD) {
		ID = iD;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getGenere() {
		return genere;
	}
	public void setGenere(String genere) {
		this.genere = genere;
	}
	public String getAutore() {
		return autore;
	}
	public void setAutore(String autore) {
		this.autore = autore;
	}
	public int getValutazione() {
		return valutazione;
	}
	public void setValutazione(int valutazione) {
		this.valutazione = valutazione;
	}
	public byte[] getImage() {
		return image;
	}
	public void setImage(byte[] image) {
		this.image = image;
	}
	@Override
	public String toString() {
		return "ProdottoBean [ID=" + ID + ", nome=" + nome + ", genere=" + genere + ", autore=" + autore
				+ ", valutazione=" + valutazione + ", image=" + Arrays.toString(image) + "]";
	}

}

