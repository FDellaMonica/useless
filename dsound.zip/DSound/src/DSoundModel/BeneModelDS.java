package DSoundModel;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedList;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;



public class BeneModelDS implements BeneModel
{
	private static DataSource ds;
	
	static {
		try {
			Context initCtx = new InitialContext();
			Context envCtx = (Context) initCtx.lookup("java:comp/env");

			ds = (DataSource) envCtx.lookup("jdbc/is");

		} catch (NamingException e) {
			System.out.println("Error:" + e.getMessage());
		}
	}

	public static String TABLE_NAME = "bene";
	
	public synchronized void doSave(BeneBean product,int idProdotto) throws SQLException 
	{
		
		
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		
		String insertSQL= "insert into bene ("
											 + "Nickname,"
											 + "Email,"
											 + "dataacquisto,"
											 + "nomeprodotto,"
											 + "prezzoprodotto,"
											 + "nomeutente,"
											 + "cognomeutente,"
											 + "immagineprodotto,"
											 + "Autore,"
											 + "Genere,"
											 + "Valutazione,"
											 + "ID_Prodotto) values (?,?,?,?,?,?,?,?,?,?,?,?);";
		
		try {
			connection = ds.getConnection();
			preparedStatement = connection.prepareStatement(insertSQL);
			
			preparedStatement.setString(1, product.getNickname());
			preparedStatement.setString(2, product.getEmail());
			preparedStatement.setDate(3, product.getAcquisto());
			preparedStatement.setString(4, product.getNomeProdotto());
			preparedStatement.setFloat(5, product.getPrezzoProdotto());
			preparedStatement.setString(6, product.getNomeUtente());
			preparedStatement.setString(7, product.getCognomeUtente());
			
			InputStream dc=new ByteArrayInputStream(product.getImmagine());
			preparedStatement.setBinaryStream(8, dc);
			
			preparedStatement.setString(9, product.getAutore());
			preparedStatement.setString(10, product.getGenere());
			preparedStatement.setString(11, String.valueOf(product.getValutazione()));
			preparedStatement.setInt(12, idProdotto);
			preparedStatement.executeUpdate();

			connection.commit();
		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
	}

	public synchronized BeneBean doRetrieveByKey(int codice) throws SQLException 
	{	
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		BeneBean bean = new BeneBean();
		
		String selectSQL = "SELECT * FROM " + ProdottoModelDS.TABLE_NAME + " WHERE NumeroSeriale = ?";

		try {
			
			connection = ds.getConnection();
			
			preparedStatement = connection.prepareStatement(selectSQL);
			preparedStatement.setInt(1, codice);
			ResultSet rs = preparedStatement.executeQuery();
			
			while (rs.next()) 
			{	
				bean.setNickname(rs.getString("nickname"));
				bean.setEmail(rs.getString("email"));
				bean.setAcquisto(rs.getDate("data acquisto"));
				bean.setNomeProdotto(rs.getString("nomeprodotto"));
				bean.setPrezzoProdotto(rs.getFloat("prezzoprodotto"));
				bean.setNomeUtente(rs.getString("nomeutente"));
				bean.setCognomeUtente(rs.getString("cognomeutente"));
				Blob imgBlob=(Blob) rs.getBlob("immagineprodotto");
				bean.setImmagine(imgBlob.getBytes(1,(int) imgBlob.length()));
				bean.setAutore(rs.getString("autore"));
				bean.setGenere(rs.getString("genere"));
				bean.setValutazione(Integer.valueOf(rs.getString("valutazione")));
			}

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
		
		return bean;
	}
	
	public synchronized ArrayList<BeneBean> doRetrieveByUtente(String mail,String nickname) throws SQLException 
	{	
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		ArrayList<BeneBean> products = new ArrayList<BeneBean>();
		String selectSQL = "SELECT * FROM bene WHERE email = ?";

		try {
			
			connection = ds.getConnection();
			preparedStatement = connection.prepareStatement(selectSQL);
			preparedStatement.setString(1, mail);
			preparedStatement.setString(2, nickname);
			ResultSet rs = preparedStatement.executeQuery();
			
			while (rs.next()) 
			{	
				BeneBean bean = new BeneBean();

				bean.setNickname(rs.getString("nickname"));
				bean.setEmail(rs.getString("email"));
				bean.setAcquisto(rs.getDate("data acquisto"));
				bean.setNomeProdotto(rs.getString("nomeprodotto"));
				bean.setPrezzoProdotto(rs.getFloat("prezzoprodotto"));
				bean.setNomeUtente(rs.getString("nomeutente"));
				bean.setCognomeUtente(rs.getString("cognomeutente"));
				Blob imgBlob=(Blob) rs.getBlob("immagineprodotto");
				bean.setImmagine(imgBlob.getBytes(1,(int) imgBlob.length()));
				bean.setAutore(rs.getString("autore"));
				bean.setGenere(rs.getString("genere"));
				bean.setValutazione(Integer.valueOf(rs.getString("valutazione")));
				products.add(bean);
				

			}

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
		
		return products;
	}

	public synchronized boolean doDelete(int codice) throws SQLException 
	{
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		int result = 0;

		String deleteSQL = "DELETE FROM bene WHERE numeroseriale = ?";

		try {
			connection = ds.getConnection();
			preparedStatement = connection.prepareStatement(deleteSQL);
			preparedStatement.setInt(1, codice);

			result = preparedStatement.executeUpdate();

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
		return (result != 0);
	}
public synchronized boolean doControl(int idprodotto, String nickname)throws SQLException{
	Connection connection=null;
	PreparedStatement preparedStatement = null;
	
	String selectSQL= "SELECT * FROM bene WHERE ID_prodotto = ? AND Nickname = ?";
	try {
		connection = ds.getConnection();
		preparedStatement = connection.prepareStatement(selectSQL);
		preparedStatement.setInt(1, idprodotto);
		preparedStatement.setString(2, nickname);
		ResultSet rs = preparedStatement.executeQuery();
		while(rs.next()) {
			return true;
		}
	}finally {
		try {
			if (preparedStatement != null)
				preparedStatement.close();
		} finally {
			if (connection != null)
				connection.close();
		}
	}
	return false;
}

	public synchronized ArrayList<BeneBean> doRetrieveAll(String order) throws SQLException {
				
		Connection connection = null;
		
		PreparedStatement preparedStatement = null;
		

		ArrayList<BeneBean> products = new ArrayList<BeneBean>();
		
		String selectSQL = "SELECT * FROM bene";
		
		if (order != null && !order.equals("")) {
			selectSQL += " ORDER BY " + order;
		}

		try {
			connection = ds.getConnection();
		
			preparedStatement = connection.prepareStatement(selectSQL);
			
			ResultSet rs = preparedStatement.executeQuery();

			while (rs.next()) {
				BeneBean bean = new BeneBean();
				
				bean.setNickname(rs.getString("nickname"));
				bean.setEmail(rs.getString("email"));
				bean.setAcquisto(rs.getDate("dataacquisto"));
				bean.setNomeProdotto(rs.getString("nomeprodotto"));
				bean.setPrezzoProdotto(rs.getFloat("prezzoprodotto"));
				bean.setNomeUtente(rs.getString("nomeutente"));
				bean.setCognomeUtente(rs.getString("cognomeutente"));
				Blob imgBlob=(Blob) rs.getBlob("immagineprodotto");
				bean.setImmagine(imgBlob.getBytes(1,(int) imgBlob.length()));
				bean.setAutore(rs.getString("autore"));
				bean.setGenere(rs.getString("genere"));
				bean.setValutazione(Integer.valueOf(rs.getString("valutazione")));
				products.add(bean);
			}
			

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
	

		return products;
	}
}