package DsoundControl;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import DSoundModel.CartaDiCredito;
import DSoundModel.CartaDiCreditoDS;
import DSoundModel.CartaDiCreditoI;
import DSoundModel.LoginModel;
import DSoundModel.LoginModelDS;
import DSoundModel.UserBean;

/**
 * Servlet implementation class AuthControl
 */
@WebServlet("/AuthControl")
public class AuthControl extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static LoginModel model;
	private static CartaDiCreditoI carta;
	private static HttpSession session;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AuthControl() {
    	super();
    	model = new LoginModelDS();
    	// TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String email = request.getParameter("usrEmail");
		String password = request.getParameter("usrPass");
		session = request.getSession();
		try {
			UserBean user = model.doCheckLogin(email, password);
			if(user == null) {
				throw new Exception("Errore esecuzione login, riprovare!");
			}
			else if(user != null) {
				carta = new CartaDiCreditoDS();
			    CartaDiCredito card = carta.doRetrieve(email, user.getNickname());
				session.setAttribute("UserSession", user);
				session.setAttribute("UserCard", card);
				session.setAttribute("role", user.getRuolo());
				response.sendRedirect("/DSound/protected.jsp");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			response.sendRedirect("/Login.jsp");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
