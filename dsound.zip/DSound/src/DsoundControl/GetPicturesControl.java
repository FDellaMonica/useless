package DsoundControl;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import DSoundModel.ProdottoBean;
import DSoundModel.ProdottoModel;



public class GetPicturesControl extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
	static ProdottoModel model;
    public int switchImageToLoad=0;
	
	
    public GetPicturesControl() {super(); model =  new DSoundModel.ProdottoModelDS();}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		//String value=((String)request.getParameter("tipoDiDeploy"));
		
		//if(value!=null)	switchImageToLoad=Integer.valueOf(value);
		 switchImageToLoad=0;
		 System.out.println("hello");
		
		switch(switchImageToLoad)
		{
			case 0:
			{
				String id = (String) request.getParameter("ID");
				System.out.println(request.getParameter("ID"));

				if (id != null)
				{
					System.out.println("ciao");
					byte[] bt;
					
					try 
					{
						int intId=Integer.valueOf(id).intValue();
						
						ProdottoBean pb=model.doRetrieveByKey(intId);
						bt = pb.getImage();
						ServletOutputStream out = response.getOutputStream();
						System.out.println(intId);
						if(bt != null)
						{
							out.write(bt);
							response.setContentType("image/jpg");
						}
						out.close();
					} 
					catch (Exception e) 
					{
						System.out.println("cacca");
						e.printStackTrace();
					}
				}
			}
			break;
			
			/*case 1:
			{
				int id = Integer.valueOf((String) request.getParameter("id"));
				int imgN = Integer.valueOf((String) request.getParameter("imgN"));

				ArrayList<Ordine> ordini=(ArrayList<Ordine>) request.getSession().getAttribute("actualOrders");
				
				for(int i=0;i<ordini.size();i++)
				{
					if(ordini.get(i).getNumeroSeriale()==id)
					{
						byte[] bt=null;
						
						switch(imgN)
						{
							case 1: bt = ordini.get(i).getPreviewImmagine1(); break;
							case 2: bt = ordini.get(i).getPreviewImmagine2(); break;
							case 3: bt = ordini.get(i).getPreviewImmagine3(); break;
							case 4: bt = ordini.get(i).getPreviewImmagine4(); break;
						}
											
						ServletOutputStream out = response.getOutputStream();
						if(bt != null)
						{
							out.write(bt);
							response.setContentType("image/jpg");
						}
						out.close();

						break;
					}
				}
				
				
			}
			break;
			*/
			/*case 2:
			{
				byte[] avatar = (byte[]) request.getSession().getAttribute("userAvatar");

				if (avatar != null)
				{					
					try 
					{
						ServletOutputStream out = response.getOutputStream();
						out.write(avatar);
						response.setContentType("image/jpg");

						out.close();
					} 
					catch (Exception e) 
					{
						System.out.println("errore: "+e.getMessage());
					}
				}
			}*/
		}
	}

	
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {doGet(request, response);}

}
