package DsoundControl;

import java.io.IOException;
import java.sql.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;

import DSoundModel.CartaDiCredito;
import DSoundModel.CartaDiCreditoDS;
import DSoundModel.CartaDiCreditoI;
import DSoundModel.LoginModel;
import DSoundModel.LoginModelDS;
import DSoundModel.UserBean;

@MultipartConfig(fileSizeThreshold=1024*1024*2, maxFileSize=1024*1024*10, maxRequestSize=1024*1024*50) 
public class LoginControl extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
	static LoginModel LModel;
	static CartaDiCreditoI IModel;
	static HttpSession session;
	
       
    public LoginControl() {super(); LModel =  new LoginModelDS(); IModel=new CartaDiCreditoDS();}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {doPost(request, response);}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		System.out.println("Ready to create a new account");
		String username = request.getParameter("usrMail");
		String password = request.getParameter("usrPass");
		String isRegister = request.getParameter("registerOrNot");
		
		session=request.getSession();	
		
		String redirectedPage="/Login.jsp";
		try 
		{
			{
				switch(checkLogin(username, password))
				{
					case 0:	request.getSession().setAttribute("role", "normal"); redirectedPage = "/protected.jsp"; break;
					case 1:	request.getSession().setAttribute("role", "registered"); redirectedPage = "/protected.jsp"; break;
					case 2:	request.getSession().setAttribute("role", "admin"); redirectedPage = "/protected.jsp"; break;
				}
			}
			{
				if(checkLogin(username, password)==-1)
				{
					System.out.println("Getting data!");
					UserBean user=new UserBean();
					user.setNickname(request.getParameter("usrNick"));
					user.setEmail(request.getParameter("usrMail"));
					user.setPassword(request.getParameter("usrPass"));
					user.setRuolo("0");
					user.setNome(request.getParameter("usrName"));
					user.setCognome(request.getParameter("usrSur"));
					System.out.println(user.getNickname());
					CartaDiCredito carta = null;
					String numeroCarta = request.getParameter("numerocarta");
					String CVV = request.getParameter("CVV");
					String proprietario = request.getParameter("proprietariocarta");
					String dataScadenza = request.getParameter("datascadenza");
					if(!numeroCarta.equals("") && !CVV.equals("") && !proprietario.equals("") && !dataScadenza.equals("")) {
					System.out.println("Sono dentro l'if della carta");
					System.out.println(dataScadenza);
					System.out.println(CVV);
					System.out.println(numeroCarta);
					System.out.println(proprietario);
					carta = new CartaDiCredito();
					carta.setNumeroCarta(numeroCarta);
					carta.setCVV(Integer.valueOf(CVV));
					carta.setProprietario(proprietario);
					carta.setDataDiScadenza(Date.valueOf(dataScadenza));
					System.out.println("Adesso inserisco "+user.getNickname()+" e la sua carta!" );
					LModel.doSaveUser(user,carta);
					}
					else {
					System.out.println("Adesso inserisco "+user.getNickname());
					LModel.doSaveUser(user, null);		
					}
					switch(checkLogin(username, password))
					{
						case 0:	request.getSession().setAttribute("role", "normal"); redirectedPage = "/protected.jsp"; break;
						case 1:	request.getSession().setAttribute("role", "registered"); redirectedPage = "/protected.jsp"; break;
						case 2:	request.getSession().setAttribute("role", "owner"); redirectedPage = "/protected.jsp"; break;
					}
					
					redirectedPage = "/protected.jsp";
				}
				else
				{
					System.out.println("gia registrato");
					session.setAttribute("role", "-1");
					redirectedPage = "/Login.jsp";
				}
			}
			
		} catch (Exception e) {
			session.setAttribute("role", "-1");
			redirectedPage = "/LoginPage.jsp";
		}
		response.sendRedirect(request.getContextPath() + redirectedPage);
			
	}
	
	private int checkLogin(String mail, String password) throws Exception 
	{	
		UserBean usr=LModel.doCheckLogin(mail,password);
		CartaDiCredito carta;
		
		try {			
			if(usr!=null)
			{		
				carta=IModel.doRetrieve(usr.getEmail(), usr.getNickname());
			
				session.setAttribute("loggenUser", usr);
				session.setAttribute("loggenUserIndirizzo", carta);
			}
		
			if (usr!=null) 
			{
				if(usr.getRuolo()=="1") return 1;
				if(usr.getRuolo()=="0") return 0;
				if(usr.getRuolo()=="2") return 2;
			} 
			else throw new Exception("Invalid login and password");
		}catch(Exception e) {System.out.println("lol � craschato");}
		return -1;
	}

	
}
