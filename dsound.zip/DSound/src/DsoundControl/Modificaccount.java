package DsoundControl;

import java.io.IOException;
import java.sql.Date;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import DSoundModel.CartaDiCredito;
import DSoundModel.CartaDiCreditoDS;
import DSoundModel.CartaDiCreditoI;
import DSoundModel.LoginModel;
import DSoundModel.LoginModelDS;
import DSoundModel.UserBean;

/**
 * Servlet implementation class modificaccount
 */
@WebServlet("/modificaccount")
public class Modificaccount extends HttpServlet {
	private static final long serialVersionUID = 1L;
       static LoginModel LModel;
       static CartaDiCreditoI CModel;
       static HttpSession session;
       
   
    public Modificaccount() {
        super();
        LModel = new LoginModelDS(); CModel= new CartaDiCreditoDS();
        
    }

	
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException { doPost(request,response);}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		session=request.getSession();
		UserBean bean = ((UserBean)session.getAttribute("UserSession"));
		CartaDiCredito carta = ((CartaDiCredito)session.getAttribute("UserCard"));
		//if(((String)request.getParameter("action")).equals("Submit"))
		{
			System.out.println("modificando");
			boolean isCardNew=false;
			if(!(((String)request.getParameter("numerocarta")).equals("")) 
			&& !(((String)request.getParameter("CVV")).equals("")) 
			&& !(((String)request.getParameter("data")).equals("")) 
			&& !(((String)request.getParameter("proprietario")).equals(""))) 
			{isCardNew=true;}
			
			if(isCardNew==true) {
				if(carta==null) {carta=new CartaDiCredito(); 

				if(((String)request.getParameter("numerocarta")).length()>0) {carta.setNumeroCarta(request.getParameter("numerocarta"));}
				if(((String)request.getParameter("CVV")).length()>0) {carta.setCVV(Integer.valueOf(request.getParameter("CVV")));}
				if(((String)request.getParameter("data")).length()>0) {carta.setDataDiScadenza(Date.valueOf(request.getParameter("data")));}
				if(((String)request.getParameter("proprietario")).length()>0) {carta.setProprietario(request.getParameter("proprietario"));}
				try {
					CModel.doSaveUser(carta, bean.getEmail());
				}catch(SQLException e) {e.printStackTrace();}
			}
			}
			if(carta!=null) {
				carta.setNumeroCarta(request.getParameter("numerocarta"));
				if(!(request.getParameter("CVV").contentEquals(""))) {
				carta.setCVV(Integer.valueOf(request.getParameter("CVV")).intValue());}
				if(!(request.getParameter("data").equals(""))) {
				carta.setDataDiScadenza(Date.valueOf(request.getParameter("data")));}
				carta.setProprietario(request.getParameter("proprietario"));
				try {CModel.doUpdate(carta,bean.getEmail());}catch(SQLException e) {e.printStackTrace();}
			}
			//System.out.println(request.getParameter("nome"));
			if(((String) request.getParameter("nome")).length()>0) {bean.setNome(request.getParameter("nome"));}
			if(((String) request.getParameter("nickname")).length()>0) {bean.setNickname(request.getParameter("nickname"));}
			if(((String) request.getParameter("email")).length()>0) {bean.setEmail(request.getParameter("email"));}
			if(((String) request.getParameter("password")).length()>0) {bean.setPassword((request.getParameter("password")));}
			if(((String) request.getParameter("cognome")).length()>0) {bean.setCognome(request.getParameter("cognome"));}	
			try {
				System.out.println(bean.getNome());
				LModel.doUpdate(bean);
			}catch(SQLException e) {e.printStackTrace();}
			
		}
		RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/protected.jsp");
		dispatcher.forward(request, response);
	}

}
