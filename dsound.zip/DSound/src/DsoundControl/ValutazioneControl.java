package DsoundControl;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import DSoundModel.ProdottoModelDS;

public class ValutazioneControl extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public ValutazioneControl() {
        super();
      
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//String action = request.getParameter("action");
		//String pagina = request.getParameter("pagina");
		String valutazione = request.getParameter("valutazione");
		int id = Integer.valueOf(request.getParameter("ID"));
		HttpSession session = request.getSession();
		ProdottoModelDS model = new ProdottoModelDS();
		boolean result = false;
		try {
			result=model.setValutazioneByID(id, valutazione);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(result==false) {response.sendRedirect("ErrorPage2.jsp");return;}
		RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/index.jsp");
		dispatcher.forward(request, response);			
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		doGet(request, response);
	}

}
