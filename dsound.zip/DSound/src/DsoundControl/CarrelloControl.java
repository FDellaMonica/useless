package DsoundControl;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mysql.cj.jdbc.Blob;

import DSoundModel.BeneBean;
import DSoundModel.BeneModel;
import DSoundModel.BeneModelDS;
import DSoundModel.CartaDiCredito;
import DSoundModel.LoginModel;
import DSoundModel.LoginModelDS;
import DSoundModel.ProdottoBean;
import DSoundModel.ProdottoModel;
import DSoundModel.ProdottoModelDS;
import DSoundModel.UserBean;





public class CarrelloControl extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
    static ProdottoModel model;
    static BeneModel modelBean;
    static LoginModel LModel;
    
    public CarrelloControl() {super();  model =  new ProdottoModelDS();  modelBean =  new BeneModelDS(); LModel =  new LoginModelDS();}
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{  		
    	String checkout=request.getParameter("checkout");
		String action = request.getParameter("action");
		if(request.getParameter("ContinuaShopping")!=null) {
			action = request.getParameter("ContinuaShopping");
		}
		System.out.println("Ora sto eseguendo in carrellocontrol l'azione "+action);
		HttpSession session = request.getSession();
		
		//session.setAttribute("gmTxt", "");
		//session.setAttribute("gmName", "");

		if(action!= null) 
		{
			switch(action) 
			{
				case "rimuovi": 
					ArrayList<ProdottoBean> listaProdotti = (ArrayList<ProdottoBean>) session.getAttribute("prodotti");

					int posizioneGiaInserito=0;

		            for(int i=0;i<listaProdotti.size();i++)
		            {
		                try 
		                {
							if(listaProdotti.get(i).getID()==(model.doRetrieveByKey(Integer.parseInt(request.getParameter("id")))).getID())	{posizioneGiaInserito=i;}
						} catch (Exception e) {System.out.println("Error 1: "+e);}
		            }
		            int posizione=-1;
		            
		            for(int i=0;i<listaProdotti.size();i++)
		            {	
		            	try 
		            	{
		            		if(model.doRetrieveByKey(Integer.parseInt(request.getParameter("id"))).getID()==listaProdotti.get(i).getID()) posizione=i;
		            	} catch (Exception e) {System.out.println("Error 2: "+e);}
		            }
            
				
					listaProdotti.remove(posizione);
					if(listaProdotti.size()==0) listaProdotti = new ArrayList<ProdottoBean>();
					
					session.setAttribute("prodotti", listaProdotti);
					System.out.println("Ho rimosso");
					break;
				case"ContinuaShopping":
					RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/index.jsp");
					System.out.println("Torniamo sullo shoppino");
					dispatcher.forward(request, response);
					return;
				}
				
			/*String pagina=request.getParameter("pagina");
			if(pagina!=null)
				if(pagina.equals("1")) {response.sendRedirect(request.getContextPath()+"/index.jsp");}
				else 
				{
					RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/carrelloPage.jsp");
					dispatcher.forward(request, response);
				}else {*/
			RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/CarrelloPage.jsp");
				
			dispatcher.forward(request, response);}
		
		
	
		if(checkout!=null)
		{	
			
			try 
			{
				ArrayList<BeneBean> beni=modelBean.doRetrieveAll("");				
			} catch (SQLException e1) {e1.printStackTrace();}
			
			boolean error=false;
			
			for(int i =0;i<((ArrayList<ProdottoBean>)session.getAttribute("prodotti")).size();i++)
			{						
				try 
				{
					BeneBean bean=new BeneBean();
					UserBean usrbean=(UserBean) session.getAttribute("UserSession");
					ProdottoBean prodottoBean=((ArrayList<ProdottoBean>)session.getAttribute("prodotti")).get(i);
					CartaDiCredito carta=(CartaDiCredito) session.getAttribute("UserCard");
					if(modelBean.doControl(prodottoBean.getID(), usrbean.getNickname())) {
						response.sendRedirect(request.getContextPath()+"/index.jsp");
						return;
					}
					if(carta != null) {

					Calendar now = Calendar.getInstance();
					long millis=System.currentTimeMillis();  
					java.sql.Date data=new java.sql.Date(millis);
					

					carta.setNumeroCarta(carta.getNumeroCarta());
					carta.setCVV(carta.getCVV());
					carta.setDataDiScadenza(carta.getDataDiScadenza());
					carta.setProprietario(carta.getProprietario());
					bean.setNickname(usrbean.getNickname());
					bean.setAcquisto(data);
					bean.setEmail(usrbean.getEmail());
					bean.setNomeProdotto(prodottoBean.getNome());
					bean.setPrezzoProdotto(3);
					bean.setImmagine(prodottoBean.getImage());
					bean.setAutore(prodottoBean.getAutore());
					bean.setGenere(prodottoBean.getGenere());
					bean.setValutazione(prodottoBean.getValutazione());
					bean.setNomeProdotto(prodottoBean.getNome());
					bean.setNomeUtente(usrbean.getNome());
					bean.setCognomeUtente(usrbean.getCognome());

					modelBean.doSave(bean,prodottoBean.getID());
					
				}
					else {
						response.sendRedirect(request.getContextPath()+"/protected.jsp");
						return ;
					}
				}
				catch (Exception e) 
				{
					e.printStackTrace();
					//session.setAttribute("gmTxt", "There was a problem with your account information, please check them again.");
					//session.setAttribute("gmName", "Error");
					error=true;
				}
			}
			
			if(!error)
				session.setAttribute("prodotti", new ArrayList<ProdottoBean>());
			model.setTableName("prodotto");
			
			RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/CarrelloPage.jsp");
			dispatcher.forward(request, response);			
			
		}
	}
}

