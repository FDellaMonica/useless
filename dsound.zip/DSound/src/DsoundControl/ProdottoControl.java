package DsoundControl;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import DSoundModel.ProdottoModel;
import DSoundModel.ProdottoModelDS;
import DSoundModel.ProdottoBean;



public class ProdottoControl extends HttpServlet {
	private static final long serialVersionUID = 1L;
       static ProdottoModel model;
     public ProdottoControl() {super();model =  new ProdottoModelDS();}


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("a");
		String action = request.getParameter("action");
		String pagina = request.getParameter("pagina");
		
		HttpSession session = request.getSession();
		
		if(session.getAttribute("prodotti")==null) session.setAttribute("prodotti", new ArrayList<ProdottoBean>());
		if(action!= null) 
		{
			System.out.println("b");
			switch(action) 
			{
				case "addProdottoToCarrello": 
					System.out.println("inserendo oggetto nel carrello");
						if(session.getAttribute("prodotti")==null) 
						{
							session.setAttribute("prodotti", new ArrayList<ProdottoBean>());
						}
						else
						{
							if(session.getAttribute("UserSession") == null) {
								response.sendRedirect("Login.jsp");
								return ;
							}
							ArrayList<ProdottoBean> lista = (ArrayList<ProdottoBean>) session.getAttribute("prodotti"); 
							ProdottoBean pb;
							try 
							{
								System.out.println("c");
								pb = model.doRetrieveByKey(Integer.parseInt(request.getParameter("id")));
								
								int posizioneGiaInserito=-1;
								
								for(int i=0;i<lista.size();i++)
								{
									if(lista.get(i).getID()==(Integer.parseInt(request.getParameter("id"))))
									{
										posizioneGiaInserito=i;
									}
								}
								
								if(posizioneGiaInserito!=-1)
								{
									//lista.get(posizioneGiaInserito).setQuantitacarrello(lista.get(posizioneGiaInserito).getQuantitacarrello()+1);
								}
								else
								{
									lista.add(pb);
								}
								
							} catch (NumberFormatException e) {e.printStackTrace();} catch (SQLException e) {e.printStackTrace();}
						}		
				break;
				
				case "read":
				{
					try 
					{
						System.out.println("d");
						request.removeAttribute("product");
						ProdottoBean pc;
						pc = model.doRetrieveByKey(Integer.parseInt(request.getParameter("id")));
						request.setAttribute("product",pc);
					}
					catch(SQLException e) {System.out.println("Error:"+ e.getMessage());}
					break;
				}
		
			}
		
		}
		String sort = request.getParameter("sort");
		try 
		{	
			System.out.println("e");
			request.removeAttribute("products");
			
			request.setAttribute("products", model.doRetrieveAll(sort));
		
			session.setAttribute("listaCatalogo", request.getAttribute("products"));
		} catch (SQLException e) {System.out.println("Error:" + e.getMessage());}
			System.out.println("f");
		RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/index.jsp");
		dispatcher.forward(request, response);			
		}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
	}

}
