/**
 * 
 */
const bars = document.querySelector(".bars");
const menu = document.querySelector(".menu");
bars.addEventListener("click",() => {
	bars.classList.toggle("rotate");
	menu.classList.toggle("show-menu");
})